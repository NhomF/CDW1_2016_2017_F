<?php

class Sites {
    public  $list = array(
        'thegioididong' => [
            'name' => 'Thế giới di động',
            'url' => 'https://www.thegioididong.com',
            'request_url' => 'https://www.thegioididong.com/aj/CategoryV4/Advance',
            'form_data' => [
                'Category' => '',
                'Manufacture' => '',
                'PriceRange' => 0,
                'Feature' => '',
                'Property' => '',
                'OrderBy' => 1,
                'PageSize' => 28,
                'PageIndex' => 0,
                'Count' => 0,
                'Others' => ''
            ],
            'categories' => [
                //phones
                [
                    'id' => 42,
                    'name' => 'Điện thoại di động',
                    'manufactures' => [
                        [
                            'id' => 80,
                            'brand' => 'iPhone (Apple)',
                        ],
                        [
                            'id' => 2,
                            'brand' => 'Samsung',
                        ],
                        [
                            'id' => 1971,
                            'brand' => 'OPPO',
                        ],
                        [
                            'id' => 111,
                            'brand' => 'Asus Zenfone',
                        ],
                        [
                            'id' => 2,
                            'brand' => 'Sony',
                        ],
                        [
                            'id' => 14,
                            'brand' => 'HTC',
                        ],
                        [
                            'id' => 1,
                            'brand' => 'Nokia - Microsoft',
                        ],
                        [
                            'id' => 104,
                            'brand' => 'Huawei',
                        ],
                        [
                            'id' => 104,
                            'brand' => 'Huawei',
                        ],
                        [
                            'id' => 29,
                            'brand' => 'LG',
                        ],
                        [
                            'id' => 113,
                            'brand' => 'LENOVO',
                        ],
                        [
                            'id' => 5332,
                            'brand' => 'Itel',
                        ],
                        [
                            'id' => 5246,
                            'brand' => 'Freetel',
                        ],

                        [
                            'id' => 2323,
                            'brand' => 'Obi Worldphone',
                        ],
                        [
                            'id' => 110,
                            'brand' => 'Mobiistart',
                        ],
                         [
                            'id' => 19,
                            'brand' => 'Mobell',
                        ],
                         [
                            'id' => 27,
                            'brand' => 'Philips',
                        ],
                        [
                            'id' => 21,
                            'brand' => 'Q-Mobile',
                        ],
                        [
                            'id' => 20,
                            'brand' => 'Pantech',
                        ],



                    ],
                ],
                //endphones

//                //tablet
//                [
//                   'id' => 522,
//                    'name' => 'Tablets',
//                    'manufactures' => [
//                        [
//                            'id' => 1028,
//                            'brand' => 'iPad (Apple)',
//                        ],
//                        [
//                            'id' => 1101,
//                            'brand' => 'Samsung',
//                        ],
//                        [
//                            'id' => 1135,
//                            'brand' => 'Asus',
//                        ],
//                        [
//                            'id' => 1226,
//                            'brand' => 'Lenovo',
//                        ],
//                        [
//                            'id' => 1145,
//                            'brand' => 'Huawei',
//                        ],
//                        [
//                            'id' => 2246,
//                            'brand' => 'Mobell',
//                        ],
//                        [
//                            'id' => 1790,
//                            'brand' => 'Acer',
//                        ],
//                    ]
//                ],
//                //tablet

//                //laptop
//                //tablet
//                [
//                   'id' => 44,
//                    'name' => 'Laptop',
//                    'manufactures' => [
//                        [
//                            'id' => 203,
//                            'brand' => 'Macbook (Apple)',
//                        ],
//                        [
//                            'id' => 118,
//                            'brand' => 'Dell',
//                        ],
//                        [
//                            'id' => 128,
//                            'brand' => 'Asus',
//                        ],
//                        [
//                            'id' => 122,
//                            'brand' => 'HP-Compaq',
//                        ],
//                        [
//                            'id' => 120,
//                            'brand' => 'Lenovo',
//                        ],
//                        [
//                            'id' => 119,
//                            'brand' => 'Acer',
//                        ],
//                    ]
//                ]
//                //endtablet
            ]
        ],
    );
}
