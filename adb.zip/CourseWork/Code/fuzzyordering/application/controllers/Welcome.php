<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	private static $db;

	public function __construct() {
		parent::__construct();
		if (is_null(self::$db)) self::$db = new MongoDB\Client("mongodb://192.168.33.12:27017");
	}

	public function index()
	{
		$data = array();
		if ($this->input->method() == 'post') {
			$items = self::$db->fuzzydb->items;
			$product = $items->find(['name' => $this->input->post('product')]);
			//calculate similiar products
			$ncr = self::$db->fuzzydb->ncr->find(['name' => $this->input->post('product')]);
			$default_product_info = $items->find(['_id' => $ncr['key']]);
			$ncr['values'] = array_slice($ncr['values'], 0, 10);
			foreach ($ncr['values'] as $ncr_product) {
				$ncr_product_info = $items->find(['_id' => $ncr_product['key']]);
				$point = (EC($ncr_product_info['price'], $default_product_info['price'], $ncr['max_price']) + EC($ncr_product['value'], 0, $ncr['max_feature'])) / 2;
				$products[$point] = $ncr_product_info;
			}
			ksort($products, SORT_NUMERIC);
			$data = array('products' => $products);
		}
		$this->load->view('welcome_message', $data);
	}

	public function search()
	{
		if (($query = $this->input->get('query'))) {

			$items = self::$db->fuzzydb->item;

			$array = array();
			$search['$text'] = ['$search' => $query];
			$options["projection"] = ['score' => ['$meta' => "textScore"]];
			$options["sort"] = ["score" => ['$meta' => "textScore"]];
			$options["limit"] = 10;
			$result = $items->find($search, $options);

	    foreach ($result as $row) {
	    	if (!in_array($row['name'], $array)) $array[] = $row['name'];
	    }
	    //RETURN JSON ARRAY
	    echo json_encode ($array);
		}
	}

	private function EC($x, $y, $c)
	{
		return max(1 - abs($x - $y) / $c, 0);
	}

	private function LC($x, $y, $c)
	{
		if ($x <= $y) return 1;
		return max(1 - abs($x - $y) / $c, 0);
	}
}
