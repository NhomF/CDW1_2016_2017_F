<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Find Your Need</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

</head>
<body>

<div class="container">
	<div class="row" id="body">
		<h1 class="col-sm-offset-2">Welcome to findyourneed.com!</h1>
		<form class="form-horizontal" action="<?php echo site_url('welcome') ?>" method="post">
		  <div class="form-group">
		    <label for="product" class="col-sm-2 control-label">Product</label>
		    <div class="col-sm-4">
		      <input type="text" class="form-control" id="product" name="product" placeholder="Product Name..." autocomplete="off" data-provide="typeahead" />
		    </div>
		    <div class="col-sm-3">
		      <input type="text" class="form-control" placeholder="Tolerate">
		    </div>
		    <div class="col-sm-3">
		      <input type="text" class="form-control" placeholder="Weight">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="price" class="col-sm-2 control-label">Price</label>
		    <div class="col-sm-4">
		      <input type="text" class="form-control" id="price" placeholder="Price">
		    </div>
		    <div class="col-sm-3">
		      <input type="text" class="form-control" placeholder="Tolerate">
		    </div>
		    <div class="col-sm-3">
		      <input type="text" class="form-control" placeholder="Weight">
		    </div>
		  </div>
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-default">Find</button>
		    </div>
		  </div>
		</form>
		<!-- Product list -->
		<?php if (count($products) > 0) : ?>
		<div>Your results</div>
		<div class="table-responsive">
		  <table class="table">
		    <thead>
		      <tr>
		        <th>#</th>
		        <th>Product</th>
		        <th>Price</th>
		      </tr>
		    </thead>
		    <tbody>
				<?php $count = 1 ?>
				<?php foreach ($products as $product) : ?>
		      <tr>
		        <td><?php echo $count ?></td>
		        <td><?php echo $product['name'] ?></td>
		        <td><?php echo $product['price'] ?></td>
		      </tr>
				<?php $count++ ?>
				<?php endforeach; ?>
		    </tbody>
		  </table>
		</div>
		<?php endif; ?>
		<!-- /Product list -->
	</div>

</div>

<script type="text/javascript" src="/assets/js/jquery-3.1.1.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script type="text/javascript" src="/assets/js/bootstrap3-typeahead.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function() {
    $('#product').typeahead({
        source: function (query, process) {
            return $.get('<?php echo site_url("welcome/search") ?>' + '?query=' + query, function (data) {
                return process(data);
            }, 'json');
        }
    });
})
</script>

</body>
</html>