package org.adbs.fuzzy;

import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by minhq on 1/2/2017.
 */
public class NCREntry extends Document {
    private String name;
    private Map<String, Double> distances;
    private MaxValues maxValues;
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public NCREntry() {
        super();
        distances = new HashMap<>();
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDistances(Map<String, Double> distances) {
        this.distances = distances;
    }

    public String getName() {
        return name;
    }

    public Map<String, Double> getDistances() {
        return distances;
    }

    public void setMaxValues(MaxValues maxValues) {
        this.maxValues = maxValues;
    }

    public Document getDocument() {
        List<Document> documentDetailList = new ArrayList<>();
        ObjectId objId = new ObjectId(id);
        Document selfNested = new Document();
        selfNested.put("key", objId);
        selfNested.put("value", new Double(0));
        documentDetailList.add(selfNested);
        for (Map.Entry e : distances.entrySet()){
            Document nested = new Document();
            nested.put("key", new ObjectId(e.getKey().toString()));
            nested.put("value", e.getValue());
            documentDetailList.add(nested);
        }

        Document document = new Document();
        document.put("name", name);
        document.put("values", documentDetailList);
        document.put("max_price", maxValues.maxPrice);
        document.put("max_feature", maxValues.maxFeatureScore);

        document.put("key", objId);
        return document;
    }
}
