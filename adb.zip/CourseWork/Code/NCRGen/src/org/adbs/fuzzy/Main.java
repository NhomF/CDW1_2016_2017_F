package org.adbs.fuzzy;

import com.mongodb.client.MongoDatabase;

import java.util.List;

public class Main {

    public static final String DBADDRESS = "192.168.128.128";
    public static final int DBPORT = 27017;
    public static final String DBNAME = "adbs";

    private List<ItemDocument> itemList;

    public static void main(String[] args) throws InterruptedException {
        // write your code here

        if (args.length < 2) {
            System.out.println("Cach chay: java -jar NCRGen.jar <address> <dbName>");
            return;
        }

        String address = args[0];
        String dbName = args[1];

        Client mongoClient = new Client(address, DBPORT);
        MongoDatabase db = mongoClient.getDatabase(dbName);

        while (true) {
            long start = System.currentTimeMillis();
            NCRCalculator ncrCal = new NCRCalculator(db);
            ncrCal.calculate();
            long end = System.currentTimeMillis();
            System.out.println("NCR Geneneration time: read = " + ncrCal.readTime + "(ms) write = " + ncrCal.writeTime + "(ms)");
            Thread.sleep(10000);
        }
    }

}
