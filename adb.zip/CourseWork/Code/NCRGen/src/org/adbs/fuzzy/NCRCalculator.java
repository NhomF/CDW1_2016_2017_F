package org.adbs.fuzzy;

import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateManyModel;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.WriteModel;
import org.bson.Document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by minhq on 12/28/2016.
 */
public class NCRCalculator {
    public long readTime;
    public long writeTime;

    private MongoDatabase db;
    private HashMap<String, List<Document>> docMap;
    private List<Document> itemList;
    private Map<String, Document> featureMap;

    MongoCollection itemCollection;
    MongoCollection featureCollection;
    MongoCollection ncrCollection;

    public static final String ITEM_COLLECTION = "item";
    public static final String FEATURE_COLLECTION = "feature_category";
    public static final String NCR_COLLECTION = "ncr";

    private static final String CATEGORY_KEY = "category";
    private static final String FEATURE_KEY = "feature";

    private List<NCREntry> ncrTable;
    private Map<FeatureCategory, Double> maxFeatureByCategory;
    private Map<String, MaxValues> maxFeatureAndPriceByCategory;

    public NCRCalculator(MongoDatabase db) {
        this.db = db;
        itemList = new ArrayList<>();
        featureMap = new HashMap<>();
        docMap = new HashMap<>();
        ncrTable = new ArrayList<>();
        maxFeatureByCategory = new HashMap<>();
        maxFeatureAndPriceByCategory = new HashMap<>();
    }


    public void calculate() {
        itemCollection = db.getCollection(ITEM_COLLECTION);
        featureCollection = db.getCollection(FEATURE_COLLECTION);
        ncrCollection = db.getCollection(NCR_COLLECTION);

        System.out.println("itemCollection size=" + itemCollection.count());
        System.out.println("featureCollection size=" + featureCollection.count());

        long start = System.currentTimeMillis();
        getAllItems(itemCollection);
        getAllFeatureCategories(featureCollection);
        long end = System.currentTimeMillis();

        readTime = end - start;

        start = System.currentTimeMillis();
        featureMap.values().stream().forEach(x -> calculateNCR(x));
        end = System.currentTimeMillis();

        writeTime = end - start;
    }

    private void getAllFeatureCategories(MongoCollection collection) {
        MongoCursor<Document> cursor = collection.find().iterator();
        while (cursor.hasNext()) {
            Document d = cursor.next();
            featureMap.put(d.get(CATEGORY_KEY).toString(), d);

        }

        System.out.println("Done loading features, size = " + featureMap.size());
    }

    private void getAllItems(MongoCollection collection) {

        MongoCursor<Document> cursor = collection.find().iterator();
        while (cursor.hasNext()) {
            Document d = cursor.next();
            itemList.add(d);

        }
        System.out.println("Done loading items, size = " + itemList.size());

    }

    private void calculateNCR(Document featureCategoryDocument) {
        //from itemList and feature category,
        //we can detect items which are in the same category
        double maxFeatureScore = 0;
        long maxPrice = 0;

        String category = featureCategoryDocument.getString(CATEGORY_KEY);

        List<Document> itemFilteredList = itemList.stream().
                filter(p -> category.equalsIgnoreCase(p.get(CATEGORY_KEY).toString())).collect(Collectors.toList());
        System.out.println("Category filter: " + featureCategoryDocument + " list, size = " + itemFilteredList.size());

        int size = itemFilteredList.size();
        List<String> features = (List<String>) featureMap.get(category).get("feature");

        System.out.println("features list, size = " + features.size());

        getMaxByFeature(itemFilteredList, features, category);

        //get the combinations
        //IF NO COMBINATIONs, FEATURE SCORE = 1.0
        MaxValues maxValues = new MaxValues(maxFeatureScore, maxPrice);

        for (int i = 0; i < size; i++) {
            NCREntry entry = new NCREntry();

            Document item = itemFilteredList.get(i);
            String baseItemName = item.getString("name");
            String priceString =  item.get("price").toString();
            String baseItemId = item.getObjectId("_id").toString();
            Long price = new Long(priceString);

            if (price > maxValues.maxPrice)
                maxValues.maxPrice = price;

            entry.setName(baseItemName);
            entry.setId(baseItemId);
            entry.setMaxValues(maxValues);
            ncrTable.add(entry);

            for (int j = i + 1; j < size; j++) {
                String comparedItemName = itemFilteredList.get(j).getString("name");
                String comparedItemObjectId = itemFilteredList.get(j).getObjectId("_id").toString();
                System.out.println("Combination " + baseItemName + " - " + comparedItemName);

                double score = calculateFeatureScore(features, itemFilteredList.get(i), itemFilteredList.get(j), category);
                if (score > maxValues.maxFeatureScore)
                    maxValues.maxFeatureScore = score;
                entry.getDistances().put(comparedItemObjectId, score);
                System.out.println("Score = " + score);

            }


            if (i > 0) {
                for (int h = i; h > 0; h--) {
                    NCREntry previousEntry = ncrTable.get(h - 1);
                    //String prevName = previousEntry.getName();
                    String prevObjectId = previousEntry.getId();
                    double prevScore = previousEntry.getDistances().get(baseItemId);
                    entry.getDistances().put(prevObjectId, prevScore);
                }
            }

        }

        insertNCRTable();
    }

    private void insertNCRTable() {

        long start = System.currentTimeMillis();

        List<Document> list = ncrTable.stream().map(x -> x.getDocument()).collect(Collectors.toList());
//        ncrCollection.updateMany(list, new UpdateOptions().upsert(true));
//        ncrCollection.insertMany(list, new InsertManyOptions().ordered(false));

        List<WriteModel<Document>> writes = new ArrayList<WriteModel<Document>>();
        for (Document doc : list) {
            writes.add(
                    new UpdateManyModel<Document>(
                            new Document("name", doc.getString("name")),
                            new Document("$set", doc),
                            new UpdateOptions().upsert(true)
                    )
            );
        }

        BulkWriteResult bulkWriteResult = ncrCollection.bulkWrite(writes);

        ncrTable.clear();
    }

    private void getMaxByFeature(List<Document> itemList, List<String> features, String category) {
        int size = itemList.size();
        double max = 0;
        for (String f : features) {
            for (int i = 0; i < size; i++) {
                Document doc1 = itemList.get(i);
                for (int j = i + 1; j < size; j++) {
                    Document doc2 = itemList.get(j);
                    String f1 = ((Document) doc1.get("feature")).get(f).toString();
                    String f2 = ((Document) doc2.get("feature")).get(f).toString();
                    Double d1 = new Double(f1);
                    Double d2 = new Double(f2);
                    double delta = Math.abs(d1 - d2);
                    if (delta > max)
                        max = delta;

                }
            }
            maxFeatureByCategory.put(new FeatureCategory(category, f), max);
            max = 0;
        }
    }

    private void getMaxPriceByCategory(List<Document> itemList, List<String> features, String category) {
        int size = itemList.size();
        double max = 0;
        for (String f : features) {
            for (int i = 0; i < size; i++) {
                Document doc1 = itemList.get(i);
                for (int j = i + 1; j < size; j++) {
                    Document doc2 = itemList.get(j);
                    String f1 = ((Document) doc1.get("feature")).get(f).toString();
                    String f2 = ((Document) doc2.get("feature")).get(f).toString();
                    Double d1 = new Double(f1);
                    Double d2 = new Double(f2);
                    double delta = Math.abs(d1 - d2);
                    if (delta > max)
                        max = delta;

                }
            }
            maxFeatureByCategory.put(new FeatureCategory(category, f), max);
            max = 0;
        }
    }

    private double calculateFeatureScore(List<String> features, Document doc1, Document doc2, String category) {
        double sum = 0d;

        for (String f : features) {
            System.out.println("feature = " + f);
            String f1 = ((Document) doc1.get("feature")).get(f).toString();
            String f2 = ((Document) doc2.get("feature")).get(f).toString();
            Double d1 = new Double(f1);
            Double d2 = new Double(f2);
            double delta = Math.abs(d1 - d2);
            double max = maxFeatureByCategory.get(new FeatureCategory(category, f));
            sum += (delta / max);
        }

        return sum;
    }

    private void update() {
        //update when the document has already existed
    }

    private void insert() {
        //insert when the new document
    }
}
