package org.adbs.fuzzy;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Created by minhq on 12/28/2016.
 */
public class FeatureCategory {
    public String category;
    public String feature;

    public FeatureCategory() {

    }

    public FeatureCategory(String cat, String feature) {
        this.category = cat;
        this.feature = feature;
    }

    @Override
    public boolean equals(Object o) {

        if (o == this) return true;
        if (!(o instanceof FeatureCategory)) {
            return false;
        }

        FeatureCategory thatObject = (FeatureCategory) o;

        return Objects.equals(thatObject.category, this.category) &&
                Objects.equals(thatObject.feature, this.feature);
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, feature);
    }

    public static void main(String[] args) {
        //Test
        FeatureCategory f = new FeatureCategory("a", "b");
        FeatureCategory f2 = new FeatureCategory("a2", "b2");
        Map<FeatureCategory, String> m = new HashMap<>();
        m.put(f, "9");
        m.put(f2, "999");
        FeatureCategory f3 = new FeatureCategory("a", "b");
        System.out.println(m.get(f3));
    }
}
