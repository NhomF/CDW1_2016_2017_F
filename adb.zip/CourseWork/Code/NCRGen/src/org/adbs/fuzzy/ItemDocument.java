package org.adbs.fuzzy;

import org.bson.Document;

/**
 * Created by minhq on 12/28/2016.
 * {
     "name":"Apple Iphone 7",
     "brand":"Apple",
     "feature":{
     "ram":2,
     "cpu":4,
     "camera":12,
     "pin":1960
     },
     "category":"smartphone",
     "price":"17.090.000"
     }
 */
public class ItemDocument extends Document {
    private FeatureCategory features;
    public ItemDocument() {
        super();
    }


}
