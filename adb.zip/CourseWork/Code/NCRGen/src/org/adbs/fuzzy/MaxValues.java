package org.adbs.fuzzy;

/**
 * Created by minhq on 1/9/2017.
 */
public class MaxValues {
    public double maxFeatureScore;
    public long maxPrice;

    public MaxValues(double maxFeatureScore, long maxPrice) {
        this.maxFeatureScore = maxFeatureScore;
        this.maxPrice = maxPrice;
    }
}
