package org.adbs.fuzzy;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;

/**
 * Created by minhq on 12/28/2016.
 */
public class Client extends MongoClient {
    private static String address;
    private static int port;

    public Client(String address, int port) {
        super(address, port);
    }

    public Client(String address, MongoClientOptions opts) {
        super(address, opts);
    }

}
